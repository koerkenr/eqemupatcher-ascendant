Extract the contents of patch.zip to your root EQ directory.
